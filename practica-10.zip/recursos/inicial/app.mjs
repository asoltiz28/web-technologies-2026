import express from 'express';
import { librosIniciales } from './model/seed.mjs';
import { crearCatalogo } from './model/catalogo.mjs';

const app = express();
const PORT = 3000;
const modelo = crearCatalogo(librosIniciales);

app.use(express.json());
app.use(express.static('public'));

// TODO: GET /libros

// TODO: GET /libros/:id

// TODO: POST /libros

// TODO: PUT /libros/:id

// TODO: DELETE /libros/:id

app.listen(PORT, function () {
  console.log(`Servidor disponible en http://localhost:${PORT}/`);
});
