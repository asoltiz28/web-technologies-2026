export function crearCatalogo(librosIniciales) {
  const libros = [...librosIniciales];

  function obtenerTodos() {
    return libros;
  }

  function buscarPorId(id) {
    return libros.find((libro) => libro.id === id);
  }

  function agregar(libro) {
    // TODO: asignar un id y añadir el libro al array
  }

  function modificar(id, datos) {
    // TODO: localizar el libro y actualizar sus datos
  }

  function eliminar(id) {
    // TODO: localizar el libro y eliminarlo del array
  }

  return {
    obtenerTodos,
    buscarPorId,
    agregar,
    modificar,
    eliminar
  };
}
